// ============================================
// 跨设备消息传输服务器
// 使用 WebSocket 实现实时双向通信
// ============================================

const WebSocket = require('ws');
const http = require('http');
const fs = require('fs');
const path = require('path');

// ============================================
// 创建 HTTP 服务器（用于托管前端页面）
// ============================================
const server = http.createServer((req, res) => {
    // 安全处理路径
    let filePath = req.url === '/' ? '/index.html' : req.url;
    filePath = path.join(__dirname, '..', 'client', filePath);
    
    // 防止目录遍历攻击
    const resolvedPath = path.resolve(filePath);
    const clientDir = path.resolve(__dirname, '..', 'client');
    
    if (!resolvedPath.startsWith(clientDir)) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
    }
    
    // 读取文件
    fs.readFile(filePath, (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // 文件不存在，返回 index.html（支持前端路由）
                fs.readFile(path.join(clientDir, 'index.html'), (err2, data2) => {
                    if (err2) {
                        res.writeHead(404);
                        res.end('Not Found');
                        return;
                    }
                    res.writeHead(200, { 'Content-Type': 'text/html' });
                    res.end(data2);
                });
                return;
            }
            res.writeHead(500);
            res.end('Server Error');
            return;
        }
        
        // 设置 Content-Type
        const ext = path.extname(filePath);
        const contentTypes = {
            '.html': 'text/html',
            '.js': 'application/javascript',
            '.css': 'text/css',
            '.json': 'application/json',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.gif': 'image/gif',
            '.svg': 'image/svg+xml',
            '.ico': 'image/x-icon'
        };
        
        res.writeHead(200, { 
            'Content-Type': contentTypes[ext] || 'application/octet-stream'
        });
        res.end(data);
    });
});

// ============================================
// 创建 WebSocket 服务器
// ============================================
const wss = new WebSocket.Server({ server });

// 存储所有连接的客户端: Map<设备ID, WebSocket连接>
const clients = new Map();

// 从环境变量获取端口，默认 8080
const PORT = process.env.PORT || 8080;

server.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('📡 消息服务器已启动！');
    console.log('='.repeat(50));
    console.log(`🌐 访问地址: http://localhost:${PORT}`);
    console.log(`📱 手机访问: http://你的电脑IP:${PORT}`);
    console.log('='.repeat(50));
});

// 当有客户端连接时
wss.on('connection', (ws, req) => {
    // 从 URL 参数获取设备 ID
    const url = new URL(req.url, `http://${req.headers.host}`);
    const deviceId = url.searchParams.get('id') || 'unknown-' + Date.now();
    
    console.log(`✅ 设备连接: ${deviceId}`);
    
    // 检查该设备是否已存在连接，如果是则断开旧连接
    if (clients.has(deviceId)) {
        const oldWs = clients.get(deviceId);
        oldWs.send(JSON.stringify({
            type: 'system',
            content: '你的账号在其他地方登录了'
        }));
        oldWs.close();
    }
    
    // 保存新连接
    clients.set(deviceId, ws);
    
    // 发送欢迎消息给连接的客户端
    ws.send(JSON.stringify({
        type: 'system',
        content: `已连接成功！你的设备ID: ${deviceId}`
    }));
    
    // 广播在线设备列表给所有客户端
    broadcastOnlineDevices();
    
    // 当收到消息时
    ws.on('message', (data) => {
        try {
            const message = JSON.parse(data.toString());
            console.log(`📩 收到来自 ${deviceId} 的消息:`, message.type);
            
            switch (message.type) {
                case 'message':
                    handleTextMessage(deviceId, message);
                    break;
                case 'file':
                    handleFileMessage(deviceId, message);
                    break;
                case 'ping':
                    ws.send(JSON.stringify({ type: 'pong' }));
                    break;
                default:
                    console.log('未知消息类型:', message.type);
            }
        } catch (e) {
            console.error('❌ 消息解析错误:', e.message);
        }
    });
    
    // 当连接关闭时
    ws.on('close', () => {
        console.log(`👋 设备断开: ${deviceId}`);
        clients.delete(deviceId);
        broadcastOnlineDevices();
    });
    
    // 连接错误处理
    ws.on('error', (error) => {
        console.error(`❌ ${deviceId} 连接错误:`, error.message);
    });
});

// ============================================
// 处理文本消息
// ============================================
function handleTextMessage(fromId, message) {
    const targetId = message.to;
    
    if (targetId && clients.has(targetId)) {
        const targetWs = clients.get(targetId);
        
        const forwardMessage = {
            type: 'message',
            from: fromId,
            content: message.content,
            time: new Date().toLocaleString('zh-CN')
        };
        
        targetWs.send(JSON.stringify(forwardMessage));
        console.log(`✅ 消息已转发: ${fromId} → ${targetId}`);
        
        // 发送确认给发送者
        const sentWs = clients.get(fromId);
        if (sentWs) {
            sentWs.send(JSON.stringify({
                type: 'sent',
                to: targetId,
                content: message.content,
                time: new Date().toLocaleString('zh-CN')
            }));
        }
    } else if (targetId) {
        const sentWs = clients.get(fromId);
        if (sentWs) {
            sentWs.send(JSON.stringify({
                type: 'error',
                content: `目标设备 "${targetId}" 不在线`
            }));
        }
        console.log(`⚠️ 目标设备不在线: ${targetId}`);
    }
}

// ============================================
// 处理文件消息
// ============================================
function handleFileMessage(fromId, message) {
    const targetId = message.to;
    
    if (targetId && clients.has(targetId)) {
        const targetWs = clients.get(targetId);
        
        const forwardMessage = {
            type: 'file',
            from: fromId,
            fileName: message.fileName,
            fileType: message.fileType,
            fileData: message.fileData,
            time: new Date().toLocaleString('zh-CN')
        };
        
        targetWs.send(JSON.stringify(forwardMessage));
        console.log(`✅ 文件已转发: ${fromId} → ${targetId} (${message.fileName})`);
        
        const sentWs = clients.get(fromId);
        if (sentWs) {
            sentWs.send(JSON.stringify({
                type: 'file-sent',
                to: targetId,
                fileName: message.fileName,
                time: new Date().toLocaleString('zh-CN')
            }));
        }
    } else if (targetId) {
        const sentWs = clients.get(fromId);
        if (sentWs) {
            sentWs.send(JSON.stringify({
                type: 'error',
                content: `目标设备 "${targetId}" 不在线，无法发送文件`
            }));
        }
    }
}

// ============================================
// 广播在线设备列表
// ============================================
function broadcastOnlineDevices() {
    const onlineList = Array.from(clients.keys());
    const message = JSON.stringify({
        type: 'online-list',
        devices: onlineList,
        count: onlineList.length
    });
    
    clients.forEach((ws) => {
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(message);
        }
    });
    
    console.log(`📋 当前在线设备: ${onlineList.join(', ') || '无'}`);
}

// ============================================
// 服务器统计信息
// ============================================
setInterval(() => {
    if (clients.size > 0) {
        console.log(`📊 服务器状态: ${clients.size} 个设备在线`);
    }
}, 60000);
